package edu.ben.labs.lab7;

import org.junit.Test;

public class Lab7Test {

	@Test
	public void test() {
		String[] args = {"GreenEggsAndHam.txt"};
		Lab7.main(args);
	}

}
