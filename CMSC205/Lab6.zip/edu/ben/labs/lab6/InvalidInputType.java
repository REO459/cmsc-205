package edu.ben.labs.lab6;

/**
 * This is my invalid input type
 * 
 * @author omerb
 * @version 1.0
 */
public class InvalidInputType extends Exception {

}
